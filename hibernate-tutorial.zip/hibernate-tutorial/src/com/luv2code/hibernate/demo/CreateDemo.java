package com.luv2code.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.luv2code.hibernate.demo.entity.Instructor;
import com.luv2code.hibernate.demo.entity.InstructorDetail;
import com.luv2code.hibernate.demo.entity.Student;

public class CreateDemo {

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.buildSessionFactory();

		// create a session
		Session session = factory.getCurrentSession();

		try {
			// use the session object to save the object
			System.out.println("Creating the new student object");
			// create the student object

			Instructor tempInstructor = new Instructor("madhu","ram","madhu.chad@gmail.com");
			InstructorDetail tempInstructorDetail = new InstructorDetail("http://www.youtube.com","Luv 2 code");
			//associate the objects
			tempInstructor.setInstructordetail(tempInstructorDetail);

			// start the transaction
			session.beginTransaction();
			System.out.println("Saving the instructor" +tempInstructor);
			// save the instructor object
			//Note this will also save the details object  because of CascadeType.ALL
			session.save(tempInstructor);
			// commit the transaction
			session.getTransaction().commit();
			System.out.println("Done!");
		}

		finally {

			factory.close();
		}
	}
}